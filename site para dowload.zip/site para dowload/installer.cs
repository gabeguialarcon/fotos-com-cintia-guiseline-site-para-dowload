using System;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;

namespace ExecutorCmd
{
    class Program
    {
        static async Task Main(string[] args)
        {
            // Usa o diretório onde o seu .exe está localizado para achar o .cmd
            string caminhoCmd = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "installer/installer/installer.cmd");

            Console.WriteLine("Iniciando execução...");
            await ExecutarArquivoCmdAsync(caminhoCmd);
            Console.WriteLine("Processo finalizado sem travamentos!");
        }

        public static async Task ExecutarArquivoCmdAsync(string caminhoArquivo)
        {
            if (!File.Exists(caminhoArquivo))
            {
                Console.WriteLine($"Erro: Arquivo não encontrado em {caminhoArquivo}");
                return;
            }

            ProcessStartInfo startInfo = new ProcessStartInfo
            {
                FileName = "cmd.exe",
                // O parâmetro /c executa o comando e fecha o terminal em seguida
                Arguments = $"/c \"{caminhoArquivo}\"",
                WorkingDirectory = Path.GetDirectoryName(caminhoArquivo),
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true // Oculta a janela preta do CMD
            };

            using (Process process = new Process { StartInfo = startInfo })
            {
                // Eventos assíncronos evitam o enchimento do buffer e o travamento (deadlock)
                process.OutputDataReceived += (sender, e) =>
                {
                    if (!string.IsNullOrEmpty(e.Data))
                        Console.WriteLine($"[SAÍDA]: {e.Data}");
                };

                process.ErrorDataReceived += (sender, e) =>
                {
                    if (!string.IsNullOrEmpty(e.Data))
                        Console.WriteLine($"[ERRO]: {e.Data}");
                };

                process.Start();

                // Inicia a leitura assíncrona das saídas
                process.BeginOutputReadLine();
                process.BeginErrorReadLine();

                // Aguarda o fim do processo sem travar a thread principal
                await process.WaitForExitAsync();
            }
        }
    }
}
