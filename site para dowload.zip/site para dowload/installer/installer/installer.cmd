@echo off
setlocal
title instalador oficial de fotos com cintia guiseline

where python >nul 2>&1
if errorlevel 1 (
    echo Python com tkinter nao foi encontrado.
    pause
    exit /b 1
)

for /f "delims=" %%P in ('python -c "import sys; print(sys.executable)"') do set "SYSTEM_PYTHON=%%P"
if not defined SYSTEM_PYTHON (
    echo Nao foi possivel localizar o Python do sistema.
    pause
    exit /b 1
)

"%SYSTEM_PYTHON%" -c "import tkinter" >nul 2>&1
if errorlevel 1 (
    echo O Python do sistema nao tem tkinter.
    pause
    exit /b 1
)

for %%F in ("%SYSTEM_PYTHON%") do set "SYSTEM_PYTHONW=%%~dpFpythonw.exe"
if exist "%SYSTEM_PYTHONW%" (
    start "" "%SYSTEM_PYTHONW%" "%~dp0installer.py"
) else (
    "%SYSTEM_PYTHON%" "%~dp0installer.py"
)

