from pathlib import Path
import subprocess
import tkinter as tk
from tkinter import messagebox


SCRIPT_DIR = Path(__file__).resolve().parent
PYTHON_DIR = SCRIPT_DIR / "python-3.15.2-embed-amd64"
PYTHON_EXE = PYTHON_DIR / "python.exe"
NO_CONSOLE_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def install() -> None:
    copy_script = SCRIPT_DIR / "copy.py"
    close_script = SCRIPT_DIR / "close.py"

    if not PYTHON_EXE.is_file():
        messagebox.showerror(
            "Erro",
            f"A pasta do Python não foi encontrada:\n{PYTHON_DIR}",
            parent=root,
        )
        return

    try:
        subprocess.run(
            [str(PYTHON_EXE), str(copy_script)],
            cwd=SCRIPT_DIR,
            check=True,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            creationflags=NO_CONSOLE_WINDOW,
        )
    except subprocess.CalledProcessError as error:
        details = error.stderr.strip() or error.stdout.strip() or str(error)
        messagebox.showerror(
            "Erro na instalação",
            f"Não foi possível instalar o aplicativo:\n{details}",
            parent=root,
        )
        return
    except OSError as error:
        messagebox.showerror(
            "Erro na instalação",
            f"Não foi possível executar copy.py:\n{error}",
            parent=root,
        )
        return

    messagebox.showinfo(
        "Instalação concluída",
        "O aplicativo foi instalado com sucesso.",
        parent=root,
    )

    try:
        subprocess.run(
            [str(PYTHON_EXE), str(close_script)],
            cwd=SCRIPT_DIR,
            input="s\n",
            check=True,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            creationflags=NO_CONSOLE_WINDOW,
        )
    except subprocess.CalledProcessError as error:
        details = error.stderr.strip() or error.stdout.strip() or str(error)
        messagebox.showerror(
            "Erro",
            f"Não foi possível executar close.py:\n{details}",
            parent=root,
        )
        return
    except OSError as error:
        messagebox.showerror(
            "Erro",
            f"Não foi possível executar close.py:\n{error}",
            parent=root,
        )
        return

    root.destroy()


def toggle_fullscreen(_event=None):
    root.attributes("-fullscreen", not root.attributes("-fullscreen"))
    return "break"


def exit_fullscreen(_event=None):
    root.attributes("-fullscreen", False)
    return "break"


root = tk.Tk()
root.title("Instalador")
root.iconbitmap(str(SCRIPT_DIR / "icon.ico"))
root.geometry("1000x1000")
root.resizable(True, True)
root.bind("<F11>", toggle_fullscreen)
root.bind("<Escape>", exit_fullscreen)

tk.Label(root, text="Instalador do aplicativo").pack(padx=24, pady=(20, 12))
tk.Button(root, text="Instalar", command=install).pack(padx=24, pady=(0, 20))

root.mainloop()