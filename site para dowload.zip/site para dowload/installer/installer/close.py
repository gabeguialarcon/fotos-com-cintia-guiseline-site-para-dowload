from pathlib import Path
import sys


SCRIPT_DIR = Path(__file__).resolve().parent
PYTHON_DIR = SCRIPT_DIR / "python-3.15.2-embed-amd64"
PYTHON_EXE = PYTHON_DIR / "python.exe"

if not PYTHON_EXE.is_file():
    raise FileNotFoundError(f"A pasta do Python não foi encontrada: {PYTHON_DIR}")
if Path(sys.executable).resolve() != PYTHON_EXE.resolve():
    raise RuntimeError(f"Execute close.py usando: {PYTHON_EXE}")

response = input("para fechar digite s: ")
if response == "s":
    sys.exit()
