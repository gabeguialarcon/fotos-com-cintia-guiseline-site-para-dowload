import os
from pathlib import Path
import shutil
import subprocess
import sys


SCRIPT_DIR = Path(__file__).resolve().parent
PYTHON_DIR = SCRIPT_DIR / "python-3.15.2-embed-amd64"
PYTHON_EXE = PYTHON_DIR / "python.exe"
SOURCE_DIR = SCRIPT_DIR / "fotos com cintia guiseine site para dowload"
APP_NAME = "FotosComCintiaGuiseline"
EXECUTABLE_NAME = "FotosComCintiaGuiseline.exe"
UNINSTALLER_EXECUTABLE_NAME = "Install.exe"
APP_SHORTCUT_NAME = "Fotos com cintia guiseline site para dowload.lnk"
UNINSTALLER_SHORTCUT_NAME = "desinstalar fotos com cintia guiseline site para dowload.lnk"
NO_CONSOLE_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def create_start_menu_shortcut(executable: Path, icon: Path, shortcut_name: str) -> None:
    app_data = os.environ.get("APPDATA")
    if not app_data:
        raise RuntimeError("A variável APPDATA não está definida.")

    # Windows AppsFolder lists apps registered through the Start Menu Programs folder.
    start_menu = Path(app_data) / "Microsoft" / "Windows" / "Start Menu" / "Programs"
    start_menu.mkdir(parents=True, exist_ok=True)
    shortcut_path = start_menu / shortcut_name

    powershell = shutil.which("powershell.exe") or shutil.which("powershell")
    if not powershell:
        raise FileNotFoundError("Não foi possível localizar o PowerShell para criar o atalho.")

    command = (
        "$shell = New-Object -ComObject WScript.Shell; "
        "$shortcut = $shell.CreateShortcut($env:INSTALLER_SHORTCUT_PATH); "
        "$shortcut.TargetPath = $env:INSTALLER_APP_EXE; "
        "$shortcut.WorkingDirectory = Split-Path -LiteralPath $env:INSTALLER_APP_EXE; "
        "$shortcut.IconLocation = $env:INSTALLER_ICON_PATH + ',0'; "
        "$shortcut.Save()"
    )
    environment = os.environ.copy()
    environment["INSTALLER_SHORTCUT_PATH"] = str(shortcut_path)
    environment["INSTALLER_APP_EXE"] = str(executable)
    environment["INSTALLER_ICON_PATH"] = str(icon)

    subprocess.run(
        [powershell, "-NoProfile", "-NonInteractive", "-Command", command],
        check=True,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        env=environment,
        creationflags=NO_CONSOLE_WINDOW,
    )


def main() -> None:
    if not PYTHON_EXE.is_file():
        raise FileNotFoundError(f"A pasta do Python não foi encontrada: {PYTHON_DIR}")
    if Path(sys.executable).resolve() != PYTHON_EXE.resolve():
        raise RuntimeError(f"Execute copy.py usando: {PYTHON_EXE}")
    if not SOURCE_DIR.is_dir():
        raise FileNotFoundError(f"A pasta de origem não foi encontrada: {SOURCE_DIR}")

    source_executable = SOURCE_DIR / EXECUTABLE_NAME
    if not source_executable.is_file():
        raise FileNotFoundError(f"O executável não foi encontrado: {source_executable}")

    source_uninstaller = SOURCE_DIR / UNINSTALLER_EXECUTABLE_NAME
    if not source_uninstaller.is_file():
        raise FileNotFoundError(f"O desinstalador não foi encontrado: {source_uninstaller}")

    local_app_data = os.environ.get("LOCALAPPDATA")
    if not local_app_data:
        raise RuntimeError("A variável LOCALAPPDATA não está definida.")

    install_dir = Path(local_app_data) / "Programs" / APP_NAME
    shutil.copytree(SOURCE_DIR, install_dir, dirs_exist_ok=True)
    shutil.copytree(PYTHON_DIR, install_dir / PYTHON_DIR.name, dirs_exist_ok=True)

    installed_executable = install_dir / EXECUTABLE_NAME
    installed_uninstaller = install_dir / UNINSTALLER_EXECUTABLE_NAME
    installed_icon = install_dir / "icon.ico"
    create_start_menu_shortcut(installed_executable, installed_icon, APP_SHORTCUT_NAME)
    create_start_menu_shortcut(
        installed_uninstaller,
        installed_icon,
        UNINSTALLER_SHORTCUT_NAME,
    )

    print(f"Aplicativo instalado em: {install_dir}")
    print("Atalhos do aplicativo e do desinstalador criados no menu Iniciar.")


if __name__ == "__main__":
    main()
